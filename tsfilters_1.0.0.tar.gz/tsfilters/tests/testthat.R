library(testthat)
library(tsfilters)

test_check("tsfilters")
